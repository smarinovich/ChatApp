Welcome to ChatApp!

Thank you for downlaoding this Application. Please ensure that 'username.txt' is kept in the same folder as the Application. 

More informaton can be found on the User Documentation if the App does not boot.

Enjoy your new chatting experience :)

(c) Samuel Marinovich. Email: samuelm2022@student.stlukes.nsw.edu.au